
import React, { useState } from 'react';
import { User } from '../types';
import { authService } from '../services/authService';
import { Sparkles, ArrowRight, ShieldCheck, MessageCircle, Smartphone, Lock, Loader2 } from 'lucide-react';

interface LoginViewProps {
  onLogin: (user: User) => void;
  onGuest: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLogin, onGuest }) => {
  const [loginMethod, setLoginMethod] = useState<'wechat' | 'phone'>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleWechatLogin = async () => {
    setIsLoading(true);
    setErrorMsg('');
    try {
      const user = await authService.loginWithWeChat();
      onLogin(user);
    } catch (err) {
      setErrorMsg('微信登录失败，请重试');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!phone || !code) return;
    
    setIsLoading(true);
    setErrorMsg('');
    
    try {
      const user = await authService.loginWithPhone(phone, code);
      onLogin(user);
    } catch (err: any) {
      setErrorMsg(err.message || '登录失败');
    } finally {
      setIsLoading(false);
    }
  };

  const fillFakeCode = () => {
      setCode('1234');
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-500">
      {/* Card */}
      <div className="bg-white rounded-[2.5rem] p-8 md:p-10 shadow-[0_20px_60px_rgba(0,0,0,0.05)] border border-slate-100 max-w-md w-full text-center space-y-8 relative overflow-hidden">
        
        {/* Decorative background blur */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400"></div>
        <div className="absolute -top-20 -right-20 w-40 h-40 bg-emerald-50 rounded-full blur-3xl opacity-50 pointer-events-none"></div>

        <div className="space-y-4 relative">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-slate-900 text-white mb-2 shadow-xl shadow-slate-200 transform rotate-3 hover:rotate-6 transition-transform">
                <Sparkles size={36} className="text-emerald-400" />
            </div>
            <div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">欢迎回来</h2>
              <p className="text-slate-400 font-medium mt-2">登录以同步您的记忆卡片</p>
            </div>
        </div>

        {/* Login Form */}
        <div className="space-y-4 pt-2">
            
            {/* WeChat Button */}
            <button 
                onClick={handleWechatLogin}
                disabled={isLoading}
                className="w-full py-3.5 px-6 bg-[#07C160] hover:bg-[#06ad56] text-white rounded-2xl font-bold transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-3 shadow-lg shadow-emerald-500/20"
            >
                {isLoading && loginMethod === 'wechat' ? (
                     <Loader2 className="animate-spin" size={20} />
                ) : (
                    <>
                        <MessageCircle size={22} fill="currentColor" className="text-white" />
                        <span>微信一键登录</span>
                    </>
                )}
            </button>

            <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-100"></div>
                <span className="flex-shrink-0 mx-4 text-xs text-slate-300 font-bold">或使用手机号</span>
                <div className="flex-grow border-t border-slate-100"></div>
            </div>

            {/* Error Message */}
            {errorMsg && (
                <div className="bg-rose-50 text-rose-500 text-xs py-2 rounded-lg font-bold animate-in slide-in-from-top-2">
                    {errorMsg}
                </div>
            )}

            {/* Phone Form */}
            <form onSubmit={handlePhoneLogin} className="space-y-3">
                <div className="relative">
                    <div className="absolute left-4 top-3.5 text-slate-400">
                        <Smartphone size={18} />
                    </div>
                    <input 
                        type="tel" 
                        placeholder="手机号码" 
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-11 pr-4 font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                    />
                </div>
                <div className="flex gap-2">
                     <div className="relative flex-1">
                        <div className="absolute left-4 top-3.5 text-slate-400">
                            <Lock size={18} />
                        </div>
                        <input 
                            type="text" 
                            placeholder="验证码" 
                            value={code}
                            onChange={(e) => setCode(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-11 pr-4 font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                        />
                    </div>
                    <button 
                        type="button"
                        onClick={fillFakeCode}
                        className="px-4 bg-white border border-slate-200 text-slate-500 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors whitespace-nowrap"
                    >
                        获取验证码
                    </button>
                </div>

                 <button 
                    type="submit"
                    onClick={() => setLoginMethod('phone')}
                    disabled={isLoading || !phone || !code}
                    className="w-full py-3.5 px-6 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl font-bold transition-all flex items-center justify-center gap-3 shadow-lg shadow-slate-200"
                >
                    {isLoading && loginMethod === 'phone' ? <Loader2 className="animate-spin" size={20} /> : '登录 / 注册'}
                </button>
            </form>
            
             <button 
                type="button"
                onClick={onGuest}
                className="w-full py-3 px-6 text-slate-400 hover:text-slate-600 text-sm font-bold transition-all flex items-center justify-center gap-1"
            >
                <span>暂不登录，直接试用</span>
                <ArrowRight size={14} />
            </button>
        </div>
        
        <div className="flex items-center justify-center gap-2 text-[10px] text-slate-300 pt-2">
            <ShieldCheck size={12} />
            <span>已通过工信部安全认证</span>
        </div>
      </div>
    </div>
  );
};
